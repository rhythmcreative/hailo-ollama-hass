"""AI task entity for Hailo Ollama."""

from __future__ import annotations

import logging
import time
from typing import Any

from homeassistant.components import conversation
from homeassistant.components.ai_task import (
    AITaskEntity,
    AITaskEntityFeature,
    GenDataTask,
    GenDataTaskResult,
)
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant, callback
from homeassistant.helpers.entity_platform import AddConfigEntryEntitiesCallback

from homeassistant.helpers.dispatcher import async_dispatcher_connect, async_dispatcher_send

from .const import (
    CONF_HOST,
    CONF_MODEL,
    CONF_PORT,
    CONF_SHOW_THINKING,
    CONF_STREAMING,
    CONF_SYSTEM_PROMPT,
    DEFAULT_SHOW_THINKING,
    DEFAULT_STREAMING,
    DEFAULT_SYSTEM_PROMPT,
    DOMAIN,
    SIGNAL_AVAILABILITY_CHANGED,
    SIGNAL_METRICS_UPDATED,
)
from .conversation import HailoError, HailoOllamaClientMixin, _process_thinking

_LOGGER = logging.getLogger(__name__)


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddConfigEntryEntitiesCallback,
) -> None:
    """Set up the AI task entity."""
    async_add_entities([HailoAITaskEntity(entry)])


class HailoAITaskEntity(AITaskEntity, HailoOllamaClientMixin):
    """Hailo Ollama AI task entity for data generation tasks."""

    _attr_has_entity_name = True
    _attr_name = None
    _attr_supported_features = AITaskEntityFeature.GENERATE_DATA

    def __init__(self, entry: ConfigEntry) -> None:
        """Initialize."""
        self._entry = entry
        self._host: str = entry.data[CONF_HOST]
        self._port: int = entry.data[CONF_PORT]
        opts = entry.options or {}
        self._model: str = opts.get(CONF_MODEL) or entry.data[CONF_MODEL]
        self._system_prompt: str = opts.get(CONF_SYSTEM_PROMPT) or entry.data.get(
            CONF_SYSTEM_PROMPT, DEFAULT_SYSTEM_PROMPT
        )
        self._streaming: bool = opts.get(
            CONF_STREAMING, entry.data.get(CONF_STREAMING, DEFAULT_STREAMING)
        )
        self._show_thinking: bool = opts.get(
            CONF_SHOW_THINKING, entry.data.get(CONF_SHOW_THINKING, DEFAULT_SHOW_THINKING)
        )
        self._attr_unique_id = f"{entry.entry_id}_ai_task"
        self._base_url = f"http://{self._host}:{self._port}"

    async def async_added_to_hass(self) -> None:
        """Subscribe to availability changes."""
        self.async_on_remove(
            async_dispatcher_connect(
                self.hass,
                SIGNAL_AVAILABILITY_CHANGED.format(self._entry.entry_id),
                self._handle_availability,
            )
        )

    @callback
    def _handle_availability(self, available: bool) -> None:
        self.async_write_ha_state()

    @property
    def available(self) -> bool:
        """Return True when the Hailo-Ollama server is reachable."""
        return (
            self.hass.data.get(DOMAIN, {})
            .get(self._entry.entry_id, {})
            .get("available", True)
        )

    @property
    def device_info(self) -> dict[str, Any]:
        """Return device info."""
        return {
            "identifiers": {(DOMAIN, self._entry.entry_id)},
            "name": f"Hailo Ollama ({self._model})",
            "manufacturer": "Hailo",
            "model": self._model,
        }

    async def _async_generate_data(
        self,
        task: GenDataTask,
        chat_log: conversation.ChatLog,
    ) -> GenDataTaskResult:
        """Execute a data generation task against the Hailo-Ollama API."""
        messages = [
            {"role": "system", "content": self._system_prompt},
            {"role": "user", "content": task.instructions},
        ]

        t0 = time.monotonic()
        try:
            if self._streaming:
                data = await self._call_streaming(messages)
            else:
                data = await self._call_non_streaming(messages)
            
            # If it's a raw string (from old _call_* implementation), use it
            if isinstance(data, str):
                response_text = data
            else:
                response_text = data.get("message", {}).get("content", "")
        except HailoError as err:
            _LOGGER.error("Hailo AI task error: %s (Details: %s)", err, err.details)
            raise
        except Exception as err:
            _LOGGER.exception("Unexpected error in Hailo AI task")
            raise

        elapsed = time.monotonic() - t0
        clean_text = _process_thinking(response_text, self._show_thinking)
        async_dispatcher_send(
            self.hass,
            SIGNAL_METRICS_UPDATED.format(self._entry.entry_id),
            {"response_time": round(elapsed, 2), "response_chars": len(clean_text)},
        )
        return GenDataTaskResult(
            conversation_id=chat_log.conversation_id,
            data=clean_text,
        )
